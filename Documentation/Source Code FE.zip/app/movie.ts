export class Movie {
  mid: number;
  mname: string;
  cast: string;
  director: string;
  mgenre: string;
  mdesc: string;
  language: string;
  runTime: number;
  ticketPrice: number;
  movieCode: string;
}
