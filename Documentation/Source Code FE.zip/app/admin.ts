export class Admin {
  id: number;
  userName: string;
  emailId: string;
  password: string;
  contactNo: string;
}
