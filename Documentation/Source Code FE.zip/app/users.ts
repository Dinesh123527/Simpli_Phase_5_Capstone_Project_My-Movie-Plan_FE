export class Users {
  id: number;
  name: string;
  email: string;
  password: string;
  contactNo: string;
}