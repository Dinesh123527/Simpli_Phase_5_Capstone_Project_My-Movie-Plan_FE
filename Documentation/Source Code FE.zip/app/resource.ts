export class Resource {
  resourceCode: string;
  resourceDetail: string;
}